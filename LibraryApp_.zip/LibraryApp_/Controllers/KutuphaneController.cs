﻿using Microsoft.AspNetCore.Mvc;
using LibraryApp_.Models;

namespace LibraryApp_.Controllers
{
    public class KutuphaneController : Controller
    {
        public IActionResult Index()
        {
            return View(BookList.Kitaplar);
        }
        public IActionResult Add(string bookName)
        {
            if (string.IsNullOrWhiteSpace(bookName))
            {
                TempData["AddError"] = "Kitap adı boş olamaz.";
                return RedirectToAction("Index");
            }

            if (BookList.Kitaplar.Any(k => k.Ad.Equals(bookName, StringComparison.OrdinalIgnoreCase)))
            {
                TempData["AddError"] = "Bu kitap zaten mevcut.";
                return RedirectToAction("Index");
            }

            BookList.Kitaplar.Add(new Kitap { Ad = bookName });
            return RedirectToAction("Index");
        }


        public IActionResult Delete(string bookName)
        {
            if (string.IsNullOrWhiteSpace(bookName))

            {
                TempData["DeleteError"] = "Kitap adı boş olamaz.";
                return RedirectToAction("Index");
            }
            var bookToRemove = BookList.Kitaplar.FirstOrDefault(k => k.Ad.Equals(bookName, StringComparison.OrdinalIgnoreCase));
            if (bookToRemove == null)
            {
                TempData["DeleteError"] = "Bu kitap bulunamadı.";
                return RedirectToAction("Index");
            }
            BookList.Kitaplar.Remove(bookToRemove);
            TempData["Success"] = $"'{bookName}' başarıyla silindi.";
            return RedirectToAction("Index");

        }


        public IActionResult BookUpdate(string oldBookName, string newBookName)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(oldBookName) || string.IsNullOrWhiteSpace(newBookName))
                {
                    TempData["UpdateError"] = "Eski ve yeni kitap adı boş olamaz.";
                    return RedirectToAction("Index");
                }

                var bookToUpdate = BookList.Kitaplar
                    .FirstOrDefault(k => k.Ad.Equals(oldBookName, StringComparison.OrdinalIgnoreCase));
                //Kitap bulunamadı hatası
                if (bookToUpdate == null)
                {
                    TempData["UpdateError"] = $"'{oldBookName}' adlı kitap bulunamadı.";
                    return RedirectToAction("Index");
                }

                // Kitap zaten aynı hatası
                if (BookList.Kitaplar.Any(k => k.Ad.Equals(newBookName, StringComparison.OrdinalIgnoreCase)))
                {
                    TempData["UpdateError"] = $"'{newBookName}' adlı kitap zaten mevcut.";
                    return RedirectToAction("Index");
                }

                // Kitap güncelleme işlemi
                bookToUpdate.Ad = newBookName;
                TempData["UpdateSuccess"] = $"'{oldBookName}' başarıyla '{newBookName}' olarak güncellendi.";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["UpdateError"] = $"Güncelleme sırasında bir hata oluştu: {ex.Message}";
                return RedirectToAction("Index");
            }
        }
    }
}