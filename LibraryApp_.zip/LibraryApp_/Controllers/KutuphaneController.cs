﻿using Microsoft.AspNetCore.Mvc;
using LibraryApp_.Models;

namespace LibraryApp_.Controllers
{
    public class KutuphaneController : Controller
    {
        public IActionResult Index()
        {
            var kitaplar = new List<Kitap>
            {
                new Kitap { Ad = "1984" },
                new Kitap { Ad = "Sefiller" },
                new Kitap { Ad = "Suç ve Ceza" }
            };
            return View(kitaplar);
        }
    }
}
