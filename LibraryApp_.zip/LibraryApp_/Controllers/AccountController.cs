﻿using Microsoft.AspNetCore.Mvc;
using LibraryApp_.Models;
using LibraryApp_.Data;
using System.Linq;

namespace LibraryApp_.Controllers
{
    public class AccountController : Controller
    {
        private readonly KutuphaneContext _context;

        public AccountController(KutuphaneContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            var user = _context.Users.FirstOrDefault(u => u.Username == username);

            if (user == null || user.PasswordHash != password) // İleride hash ile karşılaştırılacak
            {
                TempData["LoginError"] = "Geçersiz kullanıcı adı veya şifre.";
                return RedirectToAction("Login");
            }

            // TODO: Kullanıcı giriş yaptıktan sonra session vs. tanımlanabilir
            return RedirectToAction("Index", "Kutuphane");
        }

        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        public IActionResult Register(string username, string password)
        {
            if (_context.Users.Any(u => u.Username == username))
            {
                TempData["RegisterError"] = "Bu kullanıcı adı zaten kullanılıyor.";
                return RedirectToAction("Register");
            }

            var newUser = new User
            {
                Username = username,
                PasswordHash = password, // Şu an düz metin; sonra hashing uygulanmalı
                CreatedAt = DateTime.Now
            };

            _context.Users.Add(newUser);
            _context.SaveChanges();

            TempData["RegisterSuccess"] = "Kayıt başarılı! Giriş yapabilirsiniz.";
            return RedirectToAction("Login");
        }
    }
}
