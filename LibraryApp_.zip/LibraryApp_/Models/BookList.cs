﻿using System.Collections.Generic;

namespace LibraryApp_.Models
{
    public static class BookList
    {
        public static List<Kitap> Kitaplar = new List<Kitap>
        {
            new Kitap { Ad = "1984" },
            new Kitap { Ad = "Sefiller" },
            new Kitap { Ad = "Suç ve Ceza" },
            new Kitap { Ad = "Küçük Prens" },
            new Kitap { Ad = "Yüzüklerin Efendisi" },
            new Kitap { Ad = "Bülbülü Öldürmek" },
            new Kitap { Ad = "Otomatik Portakal" },
        };
    }
}