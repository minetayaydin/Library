﻿namespace LibraryApp_.Models
{
    public class Kitap
    {
        public string Ad { get; set; }
    }
}
