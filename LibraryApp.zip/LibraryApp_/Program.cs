﻿using Microsoft.EntityFrameworkCore;
using LibraryApp_.Data;

namespace LibraryApp_
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();

            // ❗ Veritabanı bağlantısını burada eklemelisin:
            builder.Services.AddDbContext<KutuphaneContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("KutuphaneBaglantisi")));

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapControllerRoute(
              name: "default",
              pattern: "{controller=Kutuphane}/{action=Index}/{id?}");

            app.Run();
        }
    }
}
