﻿using LibraryApp_.Data;
using LibraryApp_.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace LibraryApp_.Controllers
{
    public class KutuphaneController : Controller
    {
        private readonly KutuphaneContext _context;

        public KutuphaneController(KutuphaneContext context)
        {
            _context = context;
        }
        public IActionResult KitapIslem()
        {
            var kitaplar = _context.Kitaplar.ToList();
            return View(kitaplar);
        }


        public IActionResult Index()
        {
            var kitaplar = _context.Kitaplar.ToList();
            return View(kitaplar);
        }

        public IActionResult Add(string bookName, string writer)
        {
            if (string.IsNullOrWhiteSpace(bookName))
            {
                TempData["AddError"] = "Kitap adı boş olamaz.";
                return RedirectToAction("KitapIslem");
            }

            // Kitap adı küçük harfe çevrilip kontrol ediliyor
            if (_context.Kitaplar.Any(k => k.Ad.ToLower() == bookName.ToLower()))
            {
                TempData["AddError"] = "Bu kitap zaten mevcut.";
                return RedirectToAction("KitapIslem");
            }

            _context.Kitaplar.Add(new Kitap { Ad = bookName, Yazar = writer });
            _context.SaveChanges();

            return RedirectToAction("KitapIslem");
        }

        public IActionResult Delete(string bookName)
        {
            if (string.IsNullOrWhiteSpace(bookName))
            {
                TempData["DeleteError"] = "Kitap adı boş olamaz.";
                return RedirectToAction("KitapIslem");
            }

            var bookToRemove = _context.Kitaplar.FirstOrDefault(k => k.Ad.ToLower() == bookName.ToLower());
            if (bookToRemove == null)
            {
                TempData["DeleteError"] = "Bu kitap bulunamadı.";
                return RedirectToAction("KitapIslem");
            }

            _context.Kitaplar.Remove(bookToRemove);
            _context.SaveChanges();

            TempData["Success"] = $"'{bookName}' başarıyla silindi.";
            return RedirectToAction("KitapIslem");
        }

        public IActionResult BookUpdate(string oldBookName, string newBookName)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(oldBookName) || string.IsNullOrWhiteSpace(newBookName))
                {
                    TempData["UpdateError"] = "Eski ve yeni kitap adı boş olamaz.";
                    return RedirectToAction("KitapIslem");
                }

                var bookToUpdate = _context.Kitaplar.FirstOrDefault(k => k.Ad.ToLower() == oldBookName.ToLower());
                if (bookToUpdate == null)
                {
                    TempData["UpdateError"] = $"'{oldBookName}' adlı kitap bulunamadı.";
                    return RedirectToAction("KitapIslem");
                }

                if (_context.Kitaplar.Any(k => k.Ad.ToLower() == newBookName.ToLower()))
                {
                    TempData["UpdateError"] = $"'{newBookName}' adlı kitap zaten mevcut.";
                    return RedirectToAction("KitapIslem");
                }

                bookToUpdate.Ad = newBookName;
                _context.SaveChanges();

                TempData["UpdateSuccess"] = $"'{oldBookName}' başarıyla '{newBookName}' olarak güncellendi.";
                return RedirectToAction("KitapIslem");
            }
            catch (System.Exception ex)
            {
                TempData["UpdateError"] = $"Güncelleme sırasında bir hata oluştu: {ex.Message}";
                return RedirectToAction("KitapIslem");
            }
        }
    }
}
