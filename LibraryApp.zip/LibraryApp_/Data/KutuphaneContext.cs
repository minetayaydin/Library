﻿using Microsoft.EntityFrameworkCore;
using LibraryApp_.Models;

namespace LibraryApp_.Data
{
    public class KutuphaneContext : DbContext
    {
        public KutuphaneContext(DbContextOptions<KutuphaneContext> options)
            : base(options)
        {
        }

        public DbSet<Kitap> Kitaplar { get; set; }
        
    }
}